package com.example.mygallery

import androidx.lifecycle.ViewModel

class GridViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}